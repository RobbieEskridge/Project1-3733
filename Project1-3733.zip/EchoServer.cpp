#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <fstream>
#include <ctime>
#include <chrono>

#define MAXPENDING 5
void DieWithError(char *errorMessage);
void HandleTCPClient(int clntSocket, char *ip);

int main(int argc, char * argv[]){
	int servSock;
	int clntSock;
	struct sockaddr_in echoServAddr;
	struct sockaddr_in echoClntAddr;
	unsigned short echoServPort;
	unsigned int clntLen;
	int currentUsers = 0;

	std::ofstream adminLog;
	adminLog.open("Log.txt", std::ios_base::app);

	std::time_t time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());

	adminLog << "Server Starting at " << std::ctime(&time) << std::endl;

	printf("Starting Connection\n");
	if(argc !=2){
		fprintf(stderr, "Usage: %s <Server Port>\n", argv[0]);
		exit(1);
	}
	echoServPort = atoi(argv[1]);
	if((servSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){
		DieWithError("socket() failed");
	}
	printf("Socket Established\n");
	memset(&echoServAddr,0,sizeof(echoServAddr));
	echoServAddr.sin_family = AF_INET;
	echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	echoServAddr.sin_port = htons(echoServPort);

	if(bind(servSock,(struct sockaddr *) &echoServAddr, sizeof(echoServAddr)) < 0){
		DieWithError("bind() failed");
	}
	printf("Bound to Socket\n");
	if(listen(servSock,MAXPENDING) < 0 ){
		DieWithError("listen() failed");
	}
	printf("listening\n");

	int totalClients = 0;
	char *clntIP;
	for(;;){
		clntLen = sizeof(echoClntAddr);
		if((clntSock = accept(servSock, (struct sockaddr *) &echoClntAddr, &clntLen)) < 0){
			DieWithError("accept() failed");
		}
		time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
		clntIP = inet_ntoa(echoClntAddr.sin_addr);
		adminLog << "Connecting to " << clntIP << " at " << std::ctime(&time) << std::endl;

		printf("Handling Client %s\n", clntIP);
	/*	pid_t pid = fork();
		currentUsers++;
		if(pid == 0){
			//child
			close(servSock);
			HandleTCPClient(clntSock);
			exit(0);
		}else if(pid < 0){
			DieWithError("The world is burning!");
		}else{
			//parent
			close(clntSock);
			totalClients++;
		}
	*/
		adminLog.close();
		HandleTCPClient(clntSock, clntIP);
	}
}

void DieWithError(char *errMsg){
	printf(errMsg);
}
void HandleTCPClient(int clntSock, char *ip){
	u_int32_t length;
	u_int32_t recievedBytesSoFar = 0;

	//retrieve length
	while(recievedBytesSoFar < 4){
		u_int32_t *placeToPutNewBytes = &length;
		placeToPutNewBytes += recievedBytesSoFar;
		int thisRound = recv(clntSock, placeToPutNewBytes, (4-recievedBytesSoFar),0);
		recievedBytesSoFar += thisRound;
	}

	//check input size
	if(length > (1 * 1024 * 1024 * 1024)){
		exit(-1);
	}

	//read message from client
	char *buffer = (char*)malloc(length);

	recievedBytesSoFar = 0;
	while(recievedBytesSoFar < length){
		char *placeToPutNewBytes = buffer;
		placeToPutNewBytes += recievedBytesSoFar;
		int thisRound =  recv(clntSock, placeToPutNewBytes, (length - recievedBytesSoFar), 0);
		recievedBytesSoFar += thisRound;
	}
	printf("Message length: %i\n", length);
	printf("Client Message: %s\n", buffer);
	//save message from client as file

	FILE *file = fopen("transmitted.png", "wb");
	fwrite(buffer, sizeof(char), length, file);
	fclose(file);
	//call java package on transmitted file
	int systemRetVal = system("java -cp javase.jar:core.jar com.google.zxing.client.j2se.CommandLineRunner transmitted.png > output.txt");	//get URL from java package

	printf("starting response\n");
	//send back to client
	u_int32_t outLen;

	FILE *fileOut = fopen("output.txt", "rb");
	fseek(fileOut, 0, SEEK_END);
	outLen = ftell(fileOut);
	rewind(fileOut);

	printf("response length: %i\n", outLen);

	char *retBuf = new char[outLen];

	send(clntSock, &outLen, 4, 0);

	printf("sent length\n");

	size_t result = fread(&retBuf, 1, outLen, fileOut);

	printf("sent response\n");

	send(clntSock, &retBuf, outLen, 0);

	fclose(fileOut);

	std::ofstream adminLog;
	adminLog.open("Log.txt", std::ios_base::app);

	std::time_t time = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());

	adminLog << "Disconnected " << ip << " at " << std::ctime(&time) << std::endl;
	adminLog.close();
	exit(0);

}

