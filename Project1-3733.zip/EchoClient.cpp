#include <iostream>
using namespace std;
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#define RCVBUFSIZE 32

void errorMessage (char* errorMessage);

int main (int argc, char *argv[]) {
	int sock;
	struct sockaddr_in echoServAddr;
	unsigned short echoServPort;
	char *servIP;
	char *QRFileName;
	fstream QRFile;
	//char echoBuffer[RCVBUFSIZE];
	int bytesRcvd, totalBytesRcvd;
	//FILE *file;
	//std::ofstream QRLog;
	//QRLog.open("Log.txt", std::ios_base::app);

	if(argc<3 || argc>4) {
		fprintf(stderr, "Usage: %s <servIP> <QRFileName> [<echoServPort>]\n", argv[0]);
		exit(1);
	}

	servIP = argv[1];
	QRFileName=argv[2];

	if(argc=4)
		echoServPort=atoi(argv[3]);
	else
		echoServPort=2000;
	printf("Connecting to Socket\n");
	if((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))<0)
		errorMessage("Socket Failed!");

	memset(&echoServAddr, 0 , sizeof(echoServAddr));
	echoServAddr.sin_family = AF_INET;
	echoServAddr.sin_addr.s_addr=inet_addr(servIP);
	echoServAddr.sin_port=htons(echoServPort);
	printf("Connecting to Server\n");
	if(connect (sock, (struct sockaddr*) &echoServAddr, sizeof(echoServAddr))<0)
		errorMessage("connect() failed");

	//send length of QR code  to server
	//send the QR code to server

	printf("Reading File\n");

	std::ifstream file;
	file.open(QRFileName, std::ios::binary);
	file.seekg(0, std::ios::end);
	u_int32_t QRFileLength = file.tellg();
	char *QRBuffer = new char[QRFileLength];
	file.seekg(0, std::ios::beg);
	file.read(QRBuffer, QRFileLength);
	file.close();

	send(sock, &QRFileLength, 4, 0);
/*
	file = fopen(QRFileName, "rb");

	if(file == NULL){
		printf("file missing");
	}

	fseek(file, 0, SEEK_END);
	QRFileLength = ftell(file);
	rewind(file);
	printf("Length of File: %i\n", QRFileLength);

	send(sock, &QRFileLength, 4, 0);

	printf("sent length \n");
	char* QRBuffer = new char[QRFileLength];
	printf("starting read\n");
	size_t result = fread(&QRBuffer, 1, QRFileLength, file);
	printf("ending read %d\n", result);
	fclose(file);
*/
//	if(result != QRFileLength){
//		printf("reading error\n");
//	}

	// my attempt to read the buffer to a file results in seg fault
	//QRLog << "Reading File " << QRBuffer << endl;
	//QRLog.close();
	printf("closing file\n");
	fflush(stdout);
	//fclose(file);

	printf("file closed \n");
	fflush(stdout);

	//QRBuffer[QRFileLength] = '\0';

	//printf("Image File Bytes: %s \n", QRBuffer);
	//fflush(stdout);
	fflush(stdout);
	if(send(sock, QRBuffer, QRFileLength, 0) != QRFileLength)
		errorMessage("Send a different num of bytes than expected");

	printf("sent message\n");

	u_int32_t recievedBytesSoFar = 0;
	u_int32_t retCode;
	while(recievedBytesSoFar < 4){
		u_int32_t *placeToPutNewBytes = &retCode;
		placeToPutNewBytes += recievedBytesSoFar;
		int thisRound = recv(sock, placeToPutNewBytes, (4 - recievedBytesSoFar), 0);
		recievedBytesSoFar += thisRound;
	}

	if(retCode == 1){
		return 0;
	}else{

		recievedBytesSoFar = 0;
		u_int32_t retLen;

		while(recievedBytesSoFar < 4){
			u_int32_t *placeToPutNewBytes = &retLen;
			placeToPutNewBytes += recievedBytesSoFar;
			int thisRound = recv(sock, placeToPutNewBytes, (4 - recievedBytesSoFar), 0);
			recievedBytesSoFar += thisRound;
		}
		printf("recieved length%i\n", retLen);
		recievedBytesSoFar = 0;
		char *buffer = new char[retLen];

		//recieve URL from server
		while(recievedBytesSoFar < retLen){
			char *placeToPutNewBytes = buffer;
			placeToPutNewBytes += recievedBytesSoFar;
			int thisRound = recv(sock, placeToPutNewBytes, (retLen - recievedBytesSoFar), 0);
			recievedBytesSoFar += thisRound;
			printf("Recieved Total: %i\n", recievedBytesSoFar);
			printf("Recieved this pass: %i\n", thisRound);
			//printf("%s", buffer);
		}
		printf("Recieved Response from Server\n");
		for(int i = 0; i < retLen; i++){
			printf("%c", buffer[i]);
		}
		fflush(stdout);
		close(sock);
		exit(0);
	}

}

void errorMessage (char* errorMessage){
	printf(errorMessage);
}
