This is the project created by Jake Matthews and Robert Eskridge. We were not able to fully test connecting
to multiple clients, though we believe the code should work given concurrent connections. Most of the QR codes
we used weren't recognized by the java program, though the one provided by professor Shue successfully transmitted
between the machines. All of the files were run from the root directory of both the client and server machines.